num = 5
while True:
    num = 2 * num
    if num % 4 == 0:
        break
print(num)
#Prediction = 20

num = 3
while num < 15:
    num += 5
print(num)
#Prediction = 18

oceans = ["Atlantic", "Pacific", "Indian", "Arctic", "Antarctic"]
i = len(oceans) - 1
while i >= 0:
    if len(oceans[i]) < 7:
        del oceans[i]
    i = i - 1
print(", ".join(oceans))
#It will print Atlantic, pacific and antarctic

for i in range(3, 7):
    print(2 * i)
#6,8,10,12
num = 5
for i in range(num, 2 * num - 2):
    print(i)
#5,6,7
for countdown in range(10, 0, -1):
    print(countdown)
#10,9,8,7,6,5,4,3,2,1
numEvens = 0
sumOfEvens = 0

list1 = [2, 9, 6, 7, 12]
for num in list1:
    if num % 2 == 0:
        numEvens += 1
        sumOfEvens += num
print(numEvens, sumOfEvens)
#3 20
numOfNumbers = 0
list1 = ["three", 4, 5.7, "six", "seven", 8, 3.1416]
for item in list1:
    if isinstance(item, str):
        continue
    numOfNumbers += 1
print(numOfNumbers)
#4

#Exercises 9-10 - Rewrite the code
#9)
for num in range(1, 10,2):
    print(num)

#10)
total = 0
count = 0
while count < 3:
    num = int(input("Enter a number"))
    total += num
    count += 1
print(total)

#Exercises 11–14 — determine the output displayed
L = ["sentence", "contains", "five", "words."]
L.insert(0, "This")
print(" ".join(L))

del L[3]
L.insert(3, "six")
L.insert(4, "different")
print(" ".join(L))
#output = This sentence contains six different words

# Assume the name entered is: Damith Hearth
name = input("Enter name with two parts: ")
L = name.split()
print("{0:s}, {1:s}".format(L[1], L[0]))
#Output = Hearth, Damith

nums = [6, 2, 8, 1]
print("Largest Number:", max(nums))
print("Length:", len(nums))
print("Total:", sum(nums))
#Output = Largest number: 8, Length: 4, Total: 17

tuple1 = ("course", "of", "human", "events", "When", "in", "the")
tuple2 = tuple1[4:] + tuple1[:4]
print(" ".join(tuple2))
#output = When in the course of human events

#Exercises 15–17 — identify all errors
# Four virtues presented by Plato
virtues = ("wisdom", "courage", "temperance", "justice")
#print(virtues[4])
#error is virtues[4] it jut needs to be virtues

list1 = [1, "two", "three", 4]
#print(" ".join(list1))
#error, there is no str instance, therefore it cannot add integers and strings together

## Display the numbers from 1 through 5.
num = 0
while True:
    num = 1
    print(num)
    num += 1
    break
#error, there is no colon after while True. It's an infinite loop

#Case Study — Movie Theatre Ticket Sales
#Part A
movies = {
    "Dune": 12.5,
    "Barbie": 11.0,
    "Oppenheimer": 13.0,
    "Spirited Away": 10.0
}

purchases = [] 

# --- Part A & D: Input Loop with Validation ---
while True:
    title = input("Enter movie title (or 'done'): ")
    if title.lower() == 'done':
        break
    
    if title not in movies:
        print("Sorry, we don't have {}. Available: {}".format(title, ', '.join(movies.keys())))
        continue

    try:
        qty_input = input("How many tickets for {}? ".format(title))
        qty = int(qty_input)
        if qty <= 0:
            print("Quantity must be positive.")
            continue
    except ValueError:
        print("Invalid input. Please enter a whole number.")
        continue

    price = movies[title]
    if qty >= 4:
        price *= 0.9
        print("Group discount applied! New price: ${:.2f}".format(price))

    purchases.append((title, qty, price))

# --- Part B: Receipt ---
print("\n--- RECEIPT ---")
grand_total = 0
for title, qty, price in purchases:
    line_total = qty * price
    grand_total += line_total
    print("{}: {} x ${:.2f} = ${:.2f}".format(title, qty, price, line_total))

is_member = input("Do you have a member code? (yes/no): ").lower() == 'yes'
if is_member:
    grand_total *= 0.95
    print("Member discount (5%) applied!")

print("Grand Total: ${:.2f}".format(grand_total))

# --- Part C & E: Summary & Analytics ---
tickets_by_movie = {}
revenue_by_movie = {}

for title, qty, price in purchases:
    tickets_by_movie[title] = tickets_by_movie.get(title, 0) + qty
    revenue_by_movie[title] = revenue_by_movie.get(title, 0) + (qty * price)

print("\n--- SALES SUMMARY ---")
for title in tickets_by_movie:
    print("{}: {} tickets, ${:.2f} revenue".format(title, tickets_by_movie[title], revenue_by_movie[title]))

if tickets_by_movie:
    top_movie = max(tickets_by_movie, key=tickets_by_movie.get)
    print("\nTop Seller: {} ({} tickets)".format(top_movie, tickets_by_movie[top_movie]))

